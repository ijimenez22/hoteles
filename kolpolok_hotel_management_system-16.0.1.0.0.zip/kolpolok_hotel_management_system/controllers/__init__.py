# -*- coding: utf-8 -*-
################################################################################
#
#    kolpolok Ltd. (https://www.kolpolok.com)
#    Author: kaushik Ahmed Apu(<https://www.kolpolok.com>)
#
################################################################################
from . import kolpolok_hotel_management_system
