# -*- coding: utf-8 -*-
################################################################################
#
#    Kolpolok Ltd. (https://www.kolpolok.com)
#    Author: Kaushik Ahmed Apu(<https://www.kolpolok.com>)
#
################################################################################
from .import room_booking_detail
from .import sale_order_detail
