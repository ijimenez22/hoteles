# -*- coding: utf-8 -*-
################################################################################
#
#    Kolpolok Ltd. (https://www.kolpolok.com)
#    Author: Kaushik Ahmed Apu(<https://www.kolpolok.com>)
#
################################################################################
from . import account_move
from . import account_move_line
from . import cleaning_request
from . import cleaning_team
from . import event_booking_line
from . import fleet_booking_line
from . import fleet_vehicle_model
from . import food_booking_line
from . import hotel_amenity
from . import hotel_floor
from . import hotel_room
from . import hotel_service
from . import maintenance_request
from . import maintenance_team
from . import room_booking
from . import room_booking_line
from . import service_booking_line
