# -*- coding: utf-8 -*-
################################################################################
#
#    Kolpolok Ltd. (https://www.kolpolok.com)
#    Author: Kaushik Ahmed Apu(<https://www.kolpolok.com>)
#
################################################################################
{
    'name': 'Hotel Management',
    'version': '16.0.1.0.0',
    'category': 'Industries',
    'summary': """A complete Hotel Management System that cover all areas of 
     Hotel services""" ,
    'description': """The module helps you to manage rooms, amenities, 
     services, food, events and vehicles. End Users can book rooms and reserve 
     foods from hotel.""",
    'author': 'kolpolok',
    'company': 'kolpolok',
    'maintainer': 'kolpolok',
    'website': 'https://kolpoloktechnologies.com',
    'depends': ['account', 'event', 'fleet', 'lunch'],
    'data': [
        'security/hotel_management_odoo_groups.xml',
        'security/hotel_management_odoo_security.xml',
        'security/ir.model.access.csv',
        'data/ir_data_sequence.xml',
        'views/account_move_views.xml',
        'views/hotel_menu_views.xml',
        'views/hotel_amenity_views.xml',
        'views/hotel_service_views.xml',
        'views/hotel_floor_views.xml',
        'views/hotel_room_views.xml',
        'views/lunch_product_views.xml',
        'views/fleet_vehicle_model_views.xml',
        'views/room_booking_views.xml',
        'views/maintenance_team_views.xml',
        'views/maintenance_request_views.xml',
        'views/cleaning_team_views.xml',
        'views/cleaning_request_views.xml',
        'views/food_booking_line_views.xml',
        'views/dashboard_view.xml',
        'wizard/room_booking_detail_views.xml',
        'wizard/sale_order_detail_views.xml',
        'views/reporting_views.xml',
        'report/room_booking_reports.xml',
        'report/sale_order_reports.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'kolpolok_hotel_management_system/static/src/js/action_manager.js',
            'kolpolok_hotel_management_system/static/src/css/dashboard.css',
            'kolpolok_hotel_management_system/static/src/js/dashboard_action.js',
            'kolpolok_hotel_management_system/static/src/xml/dashboard_templates.xml',
        ],
    },
    'images': ['static/description/banner.jpg'],
    'license': 'LGPL-3',
    'installable': True,
    'auto_install': False,
    'application': True,
}
